/* Auto generated file
 */

#include "g722_plc_dsp.h"

memoryOverview g722_plc_dsp_Overview = {
    { g722_plc_dsp_PM_SegmentList, 1 },
    { g722_plc_dsp_DM_Hi_SegmentList, 7 },
    { g722_plc_dsp_DM_Lo_SegmentList, 13 }
};

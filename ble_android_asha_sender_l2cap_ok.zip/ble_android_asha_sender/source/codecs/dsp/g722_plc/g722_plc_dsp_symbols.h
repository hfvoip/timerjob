#ifndef _G722_PLC_DSP_DSP_SYMBOLS_H_
#define _G722_PLC_DSP_DSP_SYMBOLS_H_ 1

/* Auto generated file
 */

#define g722_plc_dsp_dsp_encode_base    (0x000008f2)
#define g722_plc_dsp_dsp_encode_end     (0x00000926)
#define g722_plc_dsp_dsp_decode_base    (0x000009b4)
#define g722_plc_dsp_dsp_decode_end     (0x000009e6)

#endif    /* ifndef _G722_PLC_DSP_DSP_SYMBOLS_H_ */
